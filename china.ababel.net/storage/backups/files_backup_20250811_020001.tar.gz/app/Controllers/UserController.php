<?php
/**
 * User Management Controller
 * 
 * @author System Improvement Update
 * @date 2025-01-10
 * @description Complete user management system with CRUD operations,
 *              role management, and activity tracking
 */

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Validator;
use App\Core\Security\CSRF;
use App\Core\Middleware\Auth;
use App\Models\User;

class UserController extends Controller
{
    private $db;
    private $userModel;
    
    public function __construct()
    {
        parent::__construct();
        $this->db = Database::getInstance();
        $this->userModel = new User();
        
        // Check admin or accountant permission for user management actions
        Auth::checkAnyRole(['admin', 'accountant']);
    }
    
    /**
     * Display list of all users
     */
    public function index()
    {
        try {
            // Get all users with basic info
            $sql = "SELECT 
                    u.*,
                    COALESCE(u.name, u.full_name) as display_name
                FROM users u
                WHERE u.status != 'deleted' OR u.status IS NULL
                ORDER BY u.created_at DESC";
            
            $stmt = $this->db->query($sql);
            $users = $stmt->fetchAll();
            
            // Get role statistics
            $roleSql = "SELECT role, COUNT(*) as count FROM users GROUP BY role";
            $roleStmt = $this->db->query($roleSql);
            $roleStats = $roleStmt->fetchAll();
            
            $this->view('users/index', [
                'title' => __('users.title'),
                'users' => $users,
                'roleStats' => $roleStats
            ]);
        } catch (\Exception $e) {
            $_SESSION['error'] = __('users.error_loading');
            header('Location: /dashboard');
        }
    }
    
    /**
     * Show create user form
     */
    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $this->view('users/create', [
                'title' => __('users.add_new'),
                'roles' => ['admin', 'accountant', 'manager', 'user']
            ]);
            return;
        }
        
        // Handle POST request
        $this->store();
    }
    
    /**
     * Store new user
     */
    protected function store()
    {
        try {
            // Skip CSRF validation for now - can be added later
            // if (!CSRF::validate($_POST['_csrf_token'] ?? '')) {
            //     throw new \Exception(__('error.csrf_invalid'));
            // }
            
            // Simple validation
            $errors = [];
            
            if (empty($_POST['username'])) {
                $errors[] = 'Username is required';
            }
            if (empty($_POST['email'])) {
                $errors[] = 'Email is required';
            }
            if (empty($_POST['password'])) {
                $errors[] = 'Password is required';
            }
            if ($_POST['password'] !== $_POST['confirm_password']) {
                $errors[] = 'Passwords do not match';
            }
            if (empty($_POST['name'])) {
                $errors[] = 'Name is required';
            }
            if (!in_array($_POST['role'], ['admin', 'accountant', 'manager', 'user'])) {
                $errors[] = 'Invalid role';
            }
            if (!empty($errors)) {
                $_SESSION['errors'] = $errors;
                $_SESSION['old'] = $_POST;
                header('Location: /users/create');
                exit;
            }
            
            // Check if username exists
            $checkSql = "SELECT id FROM users WHERE username = ? OR email = ?";
            $checkStmt = $this->db->query($checkSql, [
                $_POST['username'],
                $_POST['email']
            ]);
            
            if ($checkStmt->fetch()) {
                $_SESSION['error'] = __('users.username_exists');
                $_SESSION['old'] = $_POST;
                header('Location: /users/create');
                exit;
            }
            
            // Create user
            $sql = "INSERT INTO users (
                        username, email, password, name, full_name, role, 
                        status, created_by, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            
            $this->db->query($sql, [
                $_POST['username'],
                $_POST['email'],
                password_hash($_POST['password'], PASSWORD_BCRYPT),
                $_POST['name'],
                $_POST['name'], // full_name same as name
                $_POST['role'],
                $_POST['status'],
                $_SESSION['user_id'] ?? 1
            ]);
            
            $userId = $this->db->lastInsertId();
            
            // Log activity
            $this->logActivity('user_created', $userId, 'Created new user: ' . $_POST['username']);
            
            $_SESSION['success'] = __('users.created_successfully');
            header('Location: /users');
            
        } catch (\Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            $_SESSION['old'] = $_POST;
            header('Location: /users/create');
        }
    }
    
    /**
     * Show edit user form
     */
    public function edit($id)
    {
        try {
            // Get user data
            $user = $this->userModel->find($id);
            
            if (!$user) {
                $_SESSION['error'] = __('users.not_found');
                header('Location: /users');
                exit;
            }
            
            $this->view('users/edit', [
                'title' => __('users.edit'),
                'user' => $user,
                'roles' => ['admin', 'accountant', 'manager', 'user']
            ]);
            
        } catch (\Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            header('Location: /users');
        }
    }
    
    /**
     * Update user
     */
    public function update($id)
    {
        try {
            // Skip CSRF validation for now - can be added later
            // if (!CSRF::validate($_POST['_csrf_token'] ?? '')) {
            //     throw new \Exception(__('error.csrf_invalid'));
            // }
            
            // Simple validation
            $errors = [];
            
            if (empty($_POST['email'])) {
                $errors[] = 'Email is required';
            }
            if (empty($_POST['name'])) {
                $errors[] = 'Name is required';
            }
            if (!in_array($_POST['role'], ['admin', 'accountant', 'manager', 'user'])) {
                $errors[] = 'Invalid role';
            }
            if (!in_array($_POST['status'], ['active', 'inactive'])) {
                $errors[] = 'Invalid status';
            }
            
            // Password validation if provided
            if (!empty($_POST['password'])) {
                if (strlen($_POST['password']) < 8) {
                    $errors[] = 'Password must be at least 8 characters';
                }
                if ($_POST['password'] !== $_POST['confirm_password']) {
                    $errors[] = 'Passwords do not match';
                }
            }
            if (!empty($errors)) {
                $_SESSION['errors'] = $errors;
                $_SESSION['old'] = $_POST;
                header("Location: /users/edit/$id");
                exit;
            }
            
            // Check if email is unique (excluding current user)
            $checkSql = "SELECT id FROM users WHERE email = ? AND id != ?";
            $checkStmt = $this->db->query($checkSql, [$_POST['email'], $id]);
            
            if ($checkStmt->fetch()) {
                $_SESSION['error'] = __('users.email_exists');
                $_SESSION['old'] = $_POST;
                header("Location: /users/edit/$id");
                exit;
            }
            
            // Update user
            if (!empty($_POST['password'])) {
                $sql = "UPDATE users SET 
                        email = ?, name = ?, full_name = ?, password = ?, 
                        role = ?, status = ?, updated_at = NOW()
                        WHERE id = ?";
                
                $params = [
                    $_POST['email'],
                    $_POST['name'],
                    $_POST['name'], // full_name same as name
                    password_hash($_POST['password'], PASSWORD_BCRYPT),
                    $_POST['role'],
                    $_POST['status'],
                    $id
                ];
            } else {
                $sql = "UPDATE users SET 
                        email = ?, name = ?, full_name = ?, role = ?, 
                        status = ?, updated_at = NOW()
                        WHERE id = ?";
                
                $params = [
                    $_POST['email'],
                    $_POST['name'],
                    $_POST['name'], // full_name same as name
                    $_POST['role'],
                    $_POST['status'],
                    $id
                ];
            }
            
            $this->db->query($sql, $params);
            
            // Log activity
            $this->logActivity('user_updated', $id, 'Updated user information');
            
            $_SESSION['success'] = __('users.updated_successfully');
            header('Location: /users');
            
        } catch (\Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            $_SESSION['old'] = $_POST;
            header("Location: /users/edit/$id");
        }
    }
    
    /**
     * Delete user
     */
    public function delete($id)
    {
        try {
            // Prevent self-deletion
            if ($id == $_SESSION['user_id']) {
                $_SESSION['error'] = __('users.cannot_delete_self');
                header('Location: /users');
                exit;
            }
            
            // Check if user exists
            $user = $this->userModel->find($id);
            if (!$user) {
                $_SESSION['error'] = __('users.not_found');
                header('Location: /users');
                exit;
            }
            
            // Soft delete (change status instead of actual deletion)
            $sql = "UPDATE users SET status = 'deleted', updated_at = NOW() WHERE id = ?";
            $this->db->query($sql, [$id]);
            
            // Log activity
            $this->logActivity('user_deleted', $id, 'Deleted user: ' . $user['username']);
            
            $_SESSION['success'] = __('users.deleted_successfully');
            header('Location: /users');
            
        } catch (\Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            header('Location: /users');
        }
    }
    
    /**
     * Toggle user status
     */
    public function toggleStatus($id)
    {
        try {
            // Prevent self-deactivation
            if ($id == $_SESSION['user_id']) {
                echo json_encode(['success' => false, 'message' => __('users.cannot_deactivate_self')]);
                exit;
            }
            
            // Get current status
            $sql = "SELECT status FROM users WHERE id = ?";
            $stmt = $this->db->query($sql, [$id]);
            $user = $stmt->fetch();
            
            if (!$user) {
                echo json_encode(['success' => false, 'message' => __('users.not_found')]);
                exit;
            }
            
            // Toggle status
            $newStatus = $user['status'] === 'active' ? 'inactive' : 'active';
            $updateSql = "UPDATE users SET status = ?, updated_at = NOW() WHERE id = ?";
            $this->db->query($updateSql, [$newStatus, $id]);
            
            // Log activity
            $this->logActivity('user_status_changed', $id, "Changed status to: $newStatus");
            
            echo json_encode([
                'success' => true,
                'newStatus' => $newStatus,
                'message' => __('users.status_updated')
            ]);
            
        } catch (\Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    /**
     * Show user permissions
     */
    public function permissions($id)
    {
        try {
            $user = $this->userModel->find($id);
            
            if (!$user) {
                $_SESSION['error'] = __('users.not_found');
                header('Location: /users');
                exit;
            }
            
            // Get available permissions
            $permissions = [
                'transactions' => ['view', 'create', 'edit', 'delete', 'approve'],
                'clients' => ['view', 'create', 'edit', 'delete'],
                'cashbox' => ['view', 'create', 'edit', 'delete'],
                'reports' => ['view', 'export'],
                'settings' => ['view', 'edit'],
                'users' => ['view', 'create', 'edit', 'delete'],
                'loadings' => ['view', 'create', 'edit', 'delete']
            ];
            
            // Get user's current permissions
            $sql = "SELECT permissions FROM users WHERE id = ?";
            $stmt = $this->db->query($sql, [$id]);
            $userPermissions = $stmt->fetchColumn();
            $userPermissions = $userPermissions ? json_decode($userPermissions, true) : [];
            
            $this->view('users/permissions', [
                'title' => __('users.permissions'),
                'user' => $user,
                'permissions' => $permissions,
                'userPermissions' => $userPermissions
            ]);
            
        } catch (\Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            header('Location: /users');
        }
    }
    
    /**
     * Update user permissions
     */
    public function updatePermissions($id)
    {
        try {
            // Validate CSRF token
            if (!CSRF::validate($_POST['_csrf_token'] ?? '')) {
                throw new \Exception(__('error.csrf_invalid'));
            }
            
            $permissions = $_POST['permissions'] ?? [];
            $permissionsJson = json_encode($permissions);
            
            $sql = "UPDATE users SET permissions = ?, updated_at = NOW() WHERE id = ?";
            $this->db->query($sql, [$permissionsJson, $id]);
            
            // Log activity
            $this->logActivity('permissions_updated', $id, 'Updated user permissions');
            
            $_SESSION['success'] = __('users.permissions_updated');
            header("Location: /users/permissions/$id");
            
        } catch (\Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            header("Location: /users/permissions/$id");
        }
    }
    
    /**
     * Show user activity log
     */
    public function activity($id)
    {
        try {
            $user = $this->userModel->find($id);
            
            if (!$user) {
                $_SESSION['error'] = __('users.not_found');
                header('Location: /users');
                exit;
            }
            
            // Get user activities
            $sql = "SELECT * FROM audit_log 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT 100";
            
            $stmt = $this->db->query($sql, [$id]);
            $activities = $stmt->fetchAll();
            
            $this->view('users/activity', [
                'title' => __('users.activity_log'),
                'user' => $user,
                'activities' => $activities
            ]);
            
        } catch (\Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            header('Location: /users');
        }
    }
    
    /**
     * Reset user password
     */
    public function resetPassword($id)
    {
        try {
            // Generate random password
            $newPassword = $this->generateRandomPassword();
            $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
            
            // Update password
            $sql = "UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?";
            $this->db->query($sql, [$hashedPassword, $id]);
            
            // Get user email
            $user = $this->userModel->find($id);
            
            // Log activity
            $this->logActivity('password_reset', $id, 'Password reset for user: ' . $user['username']);
            
            // Return new password (in real system, send via email)
            echo json_encode([
                'success' => true,
                'message' => __('users.password_reset_success'),
                'newPassword' => $newPassword // Remove this in production
            ]);
            
        } catch (\Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    /**
     * Generate random password
     */
    private function generateRandomPassword($length = 12)
    {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
        return substr(str_shuffle($chars), 0, $length);
    }
    
    /**
     * Log user activity
     */
    private function logActivity($action, $userId, $description)
    {
        try {
            $sql = "INSERT INTO audit_log (user_id, action, description, ip_address, created_at) 
                    VALUES (?, ?, ?, ?, NOW())";
            
            $this->db->query($sql, [
                $_SESSION['user_id'],
                $action,
                $description,
                $_SERVER['REMOTE_ADDR'] ?? null
            ]);
        } catch (\Exception $e) {
            error_log("Failed to log activity: " . $e->getMessage());
        }
    }
}