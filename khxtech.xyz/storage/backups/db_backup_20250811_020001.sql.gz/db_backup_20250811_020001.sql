/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: khan
-- ------------------------------------------------------
-- Server version	10.11.10-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_sync_log`
--

DROP TABLE IF EXISTS `api_sync_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_sync_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `endpoint` varchar(100) NOT NULL,
  `method` varchar(10) NOT NULL,
  `china_loading_id` int(11) DEFAULT NULL,
  `container_id` int(11) DEFAULT NULL,
  `request_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_data`)),
  `response_code` int(11) DEFAULT NULL,
  `response_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_data`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_china_loading` (`china_loading_id`),
  KEY `idx_created` (`created_at`),
  KEY `idx_endpoint` (`endpoint`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_sync_log`
--

LOCK TABLES `api_sync_log` WRITE;
/*!40000 ALTER TABLE `api_sync_log` DISABLE KEYS */;
INSERT INTO `api_sync_log` VALUES
(1,'https://ababel.net/app/api/china_sync.php','POST',11,NULL,'{\"action\":\"create_container\",\"data\":{\"china_loading_id\":11,\"entry_date\":\"2025-07-19\",\"code\":\"1\",\"client_name\":\"Mohamed Abdulla Ali Farh\",\"loading_number\":\"80\",\"carton_count\":12,\"container_number\":\"CMAU7702683\",\"bill_number\":\"CLM-20250719-6442\",\"category\":\"\\u0627\\u062d\\u0630\\u064a\\u0629\",\"carrier\":\"TBD\",\"expected_arrival\":\"2025-08-18\",\"ship_name\":\"TBD\",\"custom_station\":\"Port Sudan\",\"office\":\"\\u0628\\u0648\\u0631\\u062a\\u0633\\u0648\\u062f\\u0627\\u0646\"}}',200,'{\"success\":true,\"http_code\":200,\"response\":\"{\\\"success\\\":true,\\\"container_id\\\":242,\\\"message\\\":\\\"Container already exists\\\",\\\"existing\\\":true}\",\"data\":{\"success\":true,\"container_id\":242,\"message\":\"Container already exists\",\"existing\":true},\"container_id\":242,\"message\":\"Container already exists\",\"existing\":true}','172.71.103.169','2025-07-19 10:55:30'),
(2,'https://ababel.net/app/api/china_sync.php','POST',10,NULL,'{\"action\":\"create_container\",\"data\":{\"china_loading_id\":10,\"entry_date\":\"2025-07-19\",\"code\":\"1\",\"client_name\":\"Mohamed Abdulla Ali Farh\",\"loading_number\":\"7\",\"carton_count\":400,\"container_number\":\"CMAU7702683\",\"bill_number\":\"CLM-20250719-5499\",\"category\":\"\\u0627\\u062d\\u0630\\u064a\\u0629\",\"carrier\":\"TBD\",\"expected_arrival\":\"2025-08-18\",\"ship_name\":\"TBD\",\"custom_station\":\"Port Sudan\",\"office\":\"\\u0628\\u0648\\u0631\\u062a\\u0633\\u0648\\u062f\\u0627\\u0646\"}}',200,'{\"success\":true,\"http_code\":200,\"response\":\"{\\\"success\\\":true,\\\"container_id\\\":243,\\\"message\\\":\\\"Container created successfully\\\"}\",\"data\":{\"success\":true,\"container_id\":243,\"message\":\"Container created successfully\"},\"container_id\":243,\"message\":\"Container created successfully\"}','172.71.103.169','2025-07-19 10:57:06'),
(3,'https://ababel.net/app/api/china_sync.php','POST',13,NULL,'{\"action\":\"create_container\",\"data\":{\"china_loading_id\":13,\"entry_date\":\"2025-07-21\",\"code\":\"1\",\"client_name\":\"Mohamed Abdulla Ali Farh\",\"loading_number\":\"7\",\"carton_count\":1,\"container_number\":\"CMAU7702683\",\"bill_number\":\"CLM-20250721-6088\",\"category\":\"\\u0627\\u062d\\u0630\\u064a\\u0629\",\"carrier\":\"TBD\",\"expected_arrival\":\"2025-08-20\",\"ship_name\":\"TBD\",\"custom_station\":\"Port Sudan\",\"office\":\"\\u0628\\u0648\\u0631\\u062a\\u0633\\u0648\\u062f\\u0627\\u0646\"}}',200,'{\"success\":true,\"http_code\":200,\"response\":\"{\\\"success\\\":true,\\\"container_id\\\":248,\\\"message\\\":\\\"Container created successfully\\\"}\",\"data\":{\"success\":true,\"container_id\":248,\"message\":\"Container created successfully\"},\"container_id\":248,\"message\":\"Container created successfully\"}','104.23.168.113','2025-07-21 07:02:55'),
(4,'https://ababel.net/app/api/china_sync.php','POST',15,NULL,'{\"action\":\"create_container\",\"data\":{\"china_loading_id\":15,\"entry_date\":\"2025-07-24\",\"code\":\"1\",\"client_name\":\"Mohamed Abdulla Ali Farh\",\"loading_number\":\"64\",\"carton_count\":12,\"container_number\":\"CMAU7702685\",\"bill_number\":\"CLM-20250724-4036\",\"category\":\"\\u0627\\u062d\\u0630\\u064a\\u0629\",\"carrier\":\"TBD\",\"expected_arrival\":\"2025-08-23\",\"ship_name\":\"TBD\",\"custom_station\":\"Port Sudan\",\"office\":\"\\u0628\\u0648\\u0631\\u062a\\u0633\\u0648\\u062f\\u0627\\u0646\"}}',200,'{\"success\":true,\"http_code\":200,\"response\":\"{\\\"success\\\":true,\\\"container_id\\\":250,\\\"message\\\":\\\"Container created successfully\\\"}\",\"data\":{\"success\":true,\"container_id\":250,\"message\":\"Container created successfully\"},\"container_id\":250,\"message\":\"Container created successfully\"}','172.71.103.173','2025-07-28 08:48:35'),
(5,'https://ababel.net/app/api/china_sync.php','POST',17,NULL,'{\"action\":\"create_container\",\"data\":{\"china_loading_id\":17,\"entry_date\":\"2025-08-07\",\"code\":\"1\",\"client_name\":\"Mohamed Abdulla Ali Farh\",\"loading_number\":\"786\",\"carton_count\":12,\"container_number\":\"CMAU7702685\",\"bill_number\":\"CLM-20250807-6673\",\"category\":\"\\u0627\\u062d\\u0630\\u064a\\u0629\",\"carrier\":\"TBD\",\"expected_arrival\":\"2025-09-06\",\"ship_name\":\"TBD\",\"custom_station\":\"Port Sudan\",\"office\":\"\\u0628\\u0648\\u0631\\u062a\\u0633\\u0648\\u062f\\u0627\\u0646\"}}',200,'{\"success\":true,\"http_code\":200,\"response\":\"<br \\/>\\n<b>Warning<\\/b>:  file_put_contents(\\/www\\/wwwroot\\/ababel\\/app\\/api\\/sync_debug.log): Failed to open stream: Permission denied in <b>\\/www\\/wwwroot\\/ababel\\/app\\/api\\/china_sync.php<\\/b> on line <b>16<\\/b><br \\/>\\n<br \\/>\\n<b>Warning<\\/b>:  file_put_contents(\\/www\\/wwwroot\\/ababel\\/app\\/api\\/sync_debug.log): Failed to open stream: Permission denied in <b>\\/www\\/wwwroot\\/ababel\\/app\\/api\\/china_sync.php<\\/b> on line <b>16<\\/b><br \\/>\\n<br \\/>\\n<b>Warning<\\/b>:  file_put_contents(\\/www\\/wwwroot\\/ababel\\/app\\/api\\/sync_debug.log): Failed to open stream: Permission denied in <b>\\/www\\/wwwroot\\/ababel\\/app\\/api\\/china_sync.php<\\/b> on line <b>16<\\/b><br \\/>\\n<br \\/>\\n<b>Warning<\\/b>:  file_put_contents(\\/www\\/wwwroot\\/ababel\\/app\\/api\\/sync_debug.log): Failed to open stream: Permission denied in <b>\\/www\\/wwwroot\\/ababel\\/app\\/api\\/china_sync.php<\\/b> on line <b>16<\\/b><br \\/>\\n<br \\/>\\n<b>Warning<\\/b>:  file_put_contents(\\/www\\/wwwroot\\/ababel\\/app\\/api\\/sync_debug.log): Failed to open stream: Permission denied in <b>\\/www\\/wwwroot\\/ababel\\/app\\/api\\/china_sync.php<\\/b> on line <b>16<\\/b><br \\/>\\n<br \\/>\\n<b>Warning<\\/b>:  file_put_contents(\\/www\\/wwwroot\\/ababel\\/app\\/api\\/sync_debug.log): Failed to open stream: Permission denied in <b>\\/www\\/wwwroot\\/ababel\\/app\\/api\\/china_sync.php<\\/b> on line <b>16<\\/b><br \\/>\\n{\\\"success\\\":true,\\\"container_id\\\":253,\\\"message\\\":\\\"Container created successfully\\\"}\",\"data\":null}','104.23.166.114','2025-08-07 12:59:03');
/*!40000 ALTER TABLE `api_sync_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES
(1,1,'issue_bol','loadings',15,NULL,'{\"bol_number\":\"BOL-20250730-0015\"}',NULL,NULL,'2025-07-30 13:44:51'),
(2,1,'issue_bol','loadings',17,NULL,'{\"bol_number\":\"BOL-20250731-0017\"}',NULL,NULL,'2025-07-31 06:50:23');
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashbox_movements`
--

DROP TABLE IF EXISTS `cashbox_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashbox_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) DEFAULT NULL,
  `movement_date` date NOT NULL,
  `movement_type` enum('in','out','transfer') NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `amount_rmb` decimal(15,2) DEFAULT 0.00,
  `amount_usd` decimal(15,2) DEFAULT 0.00,
  `amount_sdg` decimal(15,2) DEFAULT 0.00,
  `amount_aed` decimal(15,2) DEFAULT 0.00,
  `bank_name` varchar(100) DEFAULT NULL,
  `tt_number` varchar(50) DEFAULT NULL,
  `receipt_no` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `balance_after_rmb` decimal(15,2) DEFAULT NULL,
  `balance_after_usd` decimal(15,2) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `idx_cash_date` (`movement_date`),
  CONSTRAINT `cashbox_movements_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashbox_movements`
--

LOCK TABLES `cashbox_movements` WRITE;
/*!40000 ALTER TABLE `cashbox_movements` DISABLE KEYS */;
INSERT INTO `cashbox_movements` VALUES
(10,27,'2025-08-07','in','payment_received',0.00,12.00,0.00,0.00,'bank khartoum',NULL,NULL,'Payment from Mohamed Abdulla Ali Farh - TRX-2025-000002',NULL,NULL,1,'2025-08-07 12:45:42'),
(11,28,'2025-08-07','in','payment_received',2424.00,0.00,0.00,0.00,'',NULL,NULL,'Payment from Mohamed Abdulla Ali Farh - TRX-2025-000003',NULL,NULL,1,'2025-08-07 12:46:36'),
(12,30,'2025-08-07','in','payment_received',6868.00,34.00,0.00,0.00,'Bank of Khartoum',NULL,NULL,'Payment received for invoice #TRX-2025-000004',NULL,NULL,1,'2025-08-07 13:10:46'),
(13,31,'2025-08-08','in','payment_received',2424.00,10.00,0.00,0.00,'Bank of Khartoum',NULL,NULL,'Payment received for invoice #TRX-2025-000001',NULL,NULL,1,'2025-08-07 17:42:08'),
(14,32,'2025-08-08','in','payment_received',0.00,2.00,0.00,0.00,'Bank of Khartoum',NULL,NULL,'Payment received for invoice #TRX-2025-000001',NULL,NULL,1,'2025-08-07 17:42:54');
/*!40000 ALTER TABLE `cashbox_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `cashbox_summary`
--

DROP TABLE IF EXISTS `cashbox_summary`;
/*!50001 DROP VIEW IF EXISTS `cashbox_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `cashbox_summary` AS SELECT
 1 AS `balance_rmb`,
  1 AS `balance_usd`,
  1 AS `balance_sdg`,
  1 AS `balance_aed` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `client_balances`
--

DROP TABLE IF EXISTS `client_balances`;
/*!50001 DROP VIEW IF EXISTS `client_balances`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `client_balances` AS SELECT
 1 AS `id`,
  1 AS `name`,
  1 AS `client_code`,
  1 AS `total_balance_rmb`,
  1 AS `total_balance_usd`,
  1 AS `transaction_count` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_code` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL COMMENT 'Name in English',
  `name_ar` varchar(255) DEFAULT NULL COMMENT 'Name in Arabic',
  `phone` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `balance_rmb` decimal(15,2) DEFAULT 0.00,
  `balance_usd` decimal(15,2) DEFAULT 0.00,
  `balance_sdg` decimal(15,2) DEFAULT 0.00,
  `balance_aed` decimal(15,2) DEFAULT 0.00,
  `credit_limit` decimal(15,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `client_code` (`client_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'1','Mohamed Abdulla Ali Farh','محمد عبدالله علي','0910564187','hmadakhan686@gmail.com','Portsudan',11716.00,58.00,0.00,0.00,0.00,'active','2025-07-16 13:58:13','2025-08-07 17:42:54');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_audit_log`
--

DROP TABLE IF EXISTS `financial_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financial_audit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` int(11) NOT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_entity` (`entity_type`,`entity_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_audit_log`
--

LOCK TABLES `financial_audit_log` WRITE;
/*!40000 ALTER TABLE `financial_audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `financial_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loading_financial_records`
--

DROP TABLE IF EXISTS `loading_financial_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loading_financial_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loading_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `transaction_type` enum('purchase','commission','shipping') NOT NULL,
  `amount_rmb` decimal(12,2) DEFAULT 0.00,
  `amount_usd` decimal(12,2) DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_loading_id` (`loading_id`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loading_financial_records`
--

LOCK TABLES `loading_financial_records` WRITE;
/*!40000 ALTER TABLE `loading_financial_records` DISABLE KEYS */;
INSERT INTO `loading_financial_records` VALUES
(6,17,1,'purchase',2424.00,12.00,'Automatic invoice created for loading','2025-07-31 06:49:59'),
(7,18,1,'purchase',2424.00,12.00,'Automatic claim/invoice created for loading','2025-07-31 07:14:08'),
(8,19,1,'purchase',24844.00,123.00,'Automatic claim/invoice created for loading','2025-07-31 10:53:59'),
(9,20,1,'purchase',2424.00,12.00,'Automatic claim/invoice created for loading','2025-08-07 10:52:23'),
(10,21,1,'purchase',2424.00,12.00,'Automatic claim/invoice created for loading','2025-08-07 12:13:03'),
(11,22,1,'purchase',2424.00,12.00,'Automatic claim/invoice created for loading','2025-08-07 12:20:31'),
(12,23,1,'purchase',2424.00,12.00,'Automatic claim/invoice created for loading','2025-08-07 12:25:38'),
(13,24,1,'purchase',2412.00,12.00,'Automatic claim/invoice created for loading','2025-08-07 12:31:24'),
(14,25,1,'purchase',2424.00,12.00,'Automatic claim/invoice created for loading','2025-08-07 12:38:49'),
(15,26,1,'purchase',6868.00,34.00,'Automatic claim/invoice created for loading','2025-08-07 13:01:13');
/*!40000 ALTER TABLE `loading_financial_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loading_sync_log`
--

DROP TABLE IF EXISTS `loading_sync_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loading_sync_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loading_id` int(11) NOT NULL,
  `action` enum('create','update','delete','status') NOT NULL,
  `status` enum('success','failed') NOT NULL,
  `error_message` text DEFAULT NULL,
  `request_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_data`)),
  `response_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_data`)),
  `synced_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_loading_sync` (`loading_id`,`synced_at`),
  CONSTRAINT `loading_sync_log_ibfk_1` FOREIGN KEY (`loading_id`) REFERENCES `loadings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loading_sync_log`
--

LOCK TABLES `loading_sync_log` WRITE;
/*!40000 ALTER TABLE `loading_sync_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `loading_sync_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loadings`
--

DROP TABLE IF EXISTS `loadings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loadings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loading_no` varchar(50) NOT NULL,
  `shipping_date` date NOT NULL,
  `actual_shipping_date` date DEFAULT NULL,
  `arrival_date` date DEFAULT NULL,
  `claim_number` varchar(50) DEFAULT NULL,
  `bol_number` varchar(50) DEFAULT NULL,
  `bol_issued_date` date DEFAULT NULL,
  `bol_issued_by` int(11) DEFAULT NULL,
  `container_no` varchar(50) NOT NULL,
  `bl_number` varchar(50) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `client_code` varchar(20) DEFAULT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `item_description` text DEFAULT NULL,
  `cartons_count` int(11) DEFAULT 0,
  `purchase_amount` decimal(15,2) DEFAULT 0.00,
  `commission_amount` decimal(15,2) DEFAULT 0.00,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `shipping_usd` decimal(15,2) DEFAULT 0.00,
  `total_with_shipping` decimal(15,2) DEFAULT 0.00,
  `office` enum('port_sudan','uae','tanzania','egypt') DEFAULT NULL,
  `status` enum('pending','shipped','arrived','cleared','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `sync_status` enum('pending','synced','failed') DEFAULT 'pending',
  `sync_attempts` int(11) DEFAULT 0,
  `last_sync_at` timestamp NULL DEFAULT NULL,
  `port_sudan_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `shipping_date` (`shipping_date`),
  KEY `status` (`status`),
  KEY `office` (`office`),
  KEY `created_by` (`created_by`),
  KEY `idx_loading_no` (`loading_no`),
  KEY `idx_claim_number` (`claim_number`),
  KEY `idx_container_no` (`container_no`),
  KEY `idx_sync_status` (`sync_status`),
  KEY `idx_office_sync` (`office`,`sync_status`),
  KEY `idx_loadings_office_status` (`office`,`status`),
  KEY `idx_loadings_client_date` (`client_code`,`shipping_date`),
  KEY `idx_bol_number` (`bol_number`),
  KEY `fk_bol_issued_by` (`bol_issued_by`),
  CONSTRAINT `fk_bol_issued_by` FOREIGN KEY (`bol_issued_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `loadings_client_fk` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  CONSTRAINT `loadings_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loadings`
--

LOCK TABLES `loadings` WRITE;
/*!40000 ALTER TABLE `loadings` DISABLE KEYS */;
INSERT INTO `loadings` VALUES
(25,'76','2025-08-07',NULL,NULL,'CLM-20250807-7085',NULL,NULL,NULL,'CMAU7702691',NULL,1,'1','Mohamed Abdulla Ali Farh','احذية',12,12.00,12.00,24.00,12.00,2424.00,'port_sudan','pending',NULL,1,'2025-08-07 12:38:49',NULL,'2025-08-07 12:38:49','pending',0,NULL,NULL),
(26,'6753','2025-08-07',NULL,NULL,'CLM-20250807-1934',NULL,NULL,NULL,'CMAU7702343',NULL,1,'1','Mohamed Abdulla Ali Farh','احذية',34,34.00,34.00,68.00,34.00,6868.00,'port_sudan','pending',NULL,1,'2025-08-07 13:01:13',NULL,'2025-08-07 13:01:13','pending',0,NULL,NULL);
/*!40000 ALTER TABLE `loadings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `office_notifications`
--

DROP TABLE IF EXISTS `office_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `office_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `office` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_by` int(11) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `office` (`office`),
  KEY `is_read` (`is_read`),
  KEY `reference` (`reference_type`,`reference_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `office_notifications`
--

LOCK TABLES `office_notifications` WRITE;
/*!40000 ALTER TABLE `office_notifications` DISABLE KEYS */;
INSERT INTO `office_notifications` VALUES
(1,'port_sudan','new_container',1,'loading','New container CMAU7702685 assigned to your office',0,NULL,NULL,'2025-07-17 09:22:40');
/*!40000 ALTER TABLE `office_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rate_limits`
--

DROP TABLE IF EXISTS `rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rate_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(255) NOT NULL,
  `action` varchar(100) NOT NULL,
  `attempts` int(11) DEFAULT 1,
  `first_attempt_at` timestamp NULL DEFAULT current_timestamp(),
  `last_attempt_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blocked_until` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_identifier_action` (`identifier`,`action`),
  KEY `idx_blocked_until` (`blocked_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_limits`
--

LOCK TABLES `rate_limits` WRITE;
/*!40000 ALTER TABLE `rate_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `rate_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_logs`
--

DROP TABLE IF EXISTS `security_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_logs`
--

LOCK TABLES `security_logs` WRITE;
/*!40000 ALTER TABLE `security_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) DEFAULT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(20) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'exchange_rate_usd_rmb','200',NULL,'2025-07-18 15:20:02'),
(2,'exchange_rate_sdg_rmb','4000',NULL,'2025-07-16 13:53:00'),
(3,'exchange_rate_aed_rmb','1.96',NULL,'2025-07-29 07:55:44'),
(4,'company_name','شركة أبابيل للتنمية و الاستثمار المحدودة',NULL,'2025-07-16 14:49:23'),
(5,'company_address','',NULL,'2025-07-16 13:53:00'),
(6,'company_phone','',NULL,'2025-07-16 13:53:00'),
(13,'banks_list','Bank of Khartoum,Faisal Islamic Bank,Omdurman National Bank,Blue Nile Bank,Agricultural Bank of Sudan',NULL,'2025-07-16 16:13:37'),
(20,'port_sudan_api_url','https://ababel.net/app/api/china_sync.php','api','2025-07-19 10:48:31'),
(21,'port_sudan_api_key','AB@1234X-China2Port!','api','2025-07-19 10:49:08'),
(22,'sync_enabled','1','api','2025-07-17 12:37:04'),
(23,'sync_retry_attempts','3','api','2025-07-17 12:37:04'),
(46,'port_sudan_readonly','1','system','2025-07-29 07:55:44'),
(47,'allow_admin_override','1','system','2025-07-29 07:55:44');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_types`
--

DROP TABLE IF EXISTS `transaction_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) DEFAULT NULL,
  `type` enum('income','expense','transfer') NOT NULL,
  `affects_cashbox` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_types`
--

LOCK TABLES `transaction_types` WRITE;
/*!40000 ALTER TABLE `transaction_types` DISABLE KEYS */;
INSERT INTO `transaction_types` VALUES
(1,'GOODS_PURCHASE','Goods Purchase','شراء بضاعة','expense',1),
(2,'SHIPPING','Shipping Cost','تكلفة الشحن','expense',1),
(3,'PAYMENT_RECEIVED','Payment Received','دفعة مستلمة','income',1),
(4,'OFFICE_TRANSFER','Office Transfer','تحويل مكتب','transfer',1),
(5,'FACTORY_PAYMENT','Factory Payment','دفعة للمصنع','expense',1),
(6,'COMMISSION','Commission','عمولة','expense',1);
/*!40000 ALTER TABLE `transaction_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_transaction_id` int(11) DEFAULT NULL,
  `loading_id` int(11) DEFAULT NULL,
  `transaction_no` varchar(50) DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `transaction_type_id` int(11) DEFAULT NULL,
  `transaction_date` date NOT NULL,
  `description` text DEFAULT NULL,
  `description_ar` text DEFAULT NULL,
  `invoice_no` varchar(50) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `loading_no` varchar(50) DEFAULT NULL,
  `goods_amount_rmb` decimal(15,2) DEFAULT 0.00,
  `commission_rmb` decimal(15,2) DEFAULT 0.00,
  `total_amount_rmb` decimal(15,2) DEFAULT 0.00,
  `payment_rmb` decimal(15,2) DEFAULT 0.00,
  `balance_rmb` decimal(15,2) DEFAULT 0.00,
  `shipping_usd` decimal(15,2) DEFAULT 0.00,
  `payment_usd` decimal(15,2) DEFAULT 0.00,
  `balance_usd` decimal(15,2) DEFAULT 0.00,
  `payment_sdg` decimal(15,2) DEFAULT 0.00,
  `payment_aed` decimal(15,2) DEFAULT 0.00,
  `balance_sdg` decimal(15,2) DEFAULT 0.00,
  `balance_aed` decimal(15,2) DEFAULT 0.00,
  `rate_usd_rmb` decimal(10,4) DEFAULT NULL,
  `rate_sdg_rmb` decimal(10,4) DEFAULT NULL,
  `rate_aed_rmb` decimal(10,4) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `status` enum('pending','approved','cancelled') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_no` (`transaction_no`),
  UNIQUE KEY `unique_transaction_bank` (`transaction_no`,`bank_name`),
  KEY `transaction_type_id` (`transaction_type_id`),
  KEY `idx_trans_date` (`transaction_date`),
  KEY `idx_trans_client` (`client_id`),
  KEY `idx_loading_id` (`loading_id`),
  KEY `idx_parent_transaction` (`parent_transaction_id`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_types` (`id`),
  CONSTRAINT `transactions_ibfk_3` FOREIGN KEY (`loading_id`) REFERENCES `loadings` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES
(26,NULL,25,'TRX-2025-000001',1,1,'2025-08-07','Invoice for Loading #76 - Container: CMAU7702691','فاتورة للتحميل رقم 76 - حاوية: CMAU7702691','INV-20250807-76',NULL,'76',12.00,12.00,2424.00,2424.00,0.00,12.00,12.00,0.00,0.00,0.00,0.00,0.00,200.0000,NULL,NULL,1,1,'2025-08-07 20:39:05','approved','2025-08-07 12:38:49','2025-08-07 17:42:54',NULL,NULL),
(27,NULL,NULL,'TRX-2025-000002',1,2,'2025-08-07','Payment of 1 USD from Mohamed Abdulla Ali Farh (1)',NULL,NULL,'bank khartoum',NULL,0.00,0.00,0.00,0.00,0.00,0.00,12.00,-12.00,0.00,0.00,0.00,0.00,NULL,NULL,NULL,1,NULL,NULL,'approved','2025-08-07 12:45:42','2025-08-07 12:45:42',NULL,NULL),
(28,NULL,NULL,'TRX-2025-000003',1,2,'2025-08-07','Payment of 2 RMB from Mohamed Abdulla Ali Farh (1)',NULL,NULL,'',NULL,0.00,0.00,0.00,2424.00,-2424.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,NULL,NULL,NULL,1,NULL,NULL,'approved','2025-08-07 12:46:36','2025-08-07 12:46:36',NULL,NULL),
(29,NULL,26,'TRX-2025-000004',1,1,'2025-08-07','Invoice for Loading #6753 - Container: CMAU7702343','فاتورة للتحميل رقم 6753 - حاوية: CMAU7702343','INV-20250807-6753',NULL,'6753',34.00,34.00,6868.00,6868.00,0.00,34.00,34.00,0.00,0.00,0.00,0.00,0.00,200.0000,NULL,NULL,1,1,'2025-08-07 21:10:21','approved','2025-08-07 13:01:13','2025-08-07 13:10:46',NULL,NULL),
(30,29,26,'PAY-20250807-211046',1,3,'2025-08-07','Payment for invoice #TRX-2025-000004',NULL,NULL,'Bank of Khartoum',NULL,0.00,0.00,0.00,6868.00,0.00,0.00,34.00,0.00,0.00,0.00,0.00,0.00,NULL,NULL,NULL,1,1,'2025-08-07 21:10:46','approved','2025-08-07 13:10:46','2025-08-07 13:10:46',NULL,NULL),
(31,26,25,'PAY-20250808-014208',1,3,'2025-08-08','Payment for invoice #TRX-2025-000001',NULL,NULL,'Bank of Khartoum',NULL,0.00,0.00,0.00,2424.00,0.00,0.00,10.00,0.00,0.00,0.00,0.00,0.00,NULL,NULL,NULL,1,1,'2025-08-08 01:42:08','approved','2025-08-07 17:42:08','2025-08-07 17:42:08',NULL,NULL),
(32,26,25,'PAY-20250808-014254',1,3,'2025-08-08','Payment for invoice #TRX-2025-000001',NULL,NULL,'Bank of Khartoum',NULL,0.00,0.00,0.00,0.00,0.00,0.00,2.00,0.00,0.00,0.00,0.00,0.00,NULL,NULL,NULL,1,1,'2025-08-08 01:42:54','approved','2025-08-07 17:42:54','2025-08-07 17:42:54',NULL,NULL);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_sessions`
--

DROP TABLE IF EXISTS `user_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_type` enum('admin','lab_employee') NOT NULL,
  `session_token` varchar(128) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `last_activity` datetime DEFAULT current_timestamp(),
  `ended_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_session_token` (`session_token`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_sessions`
--

LOCK TABLES `user_sessions` WRITE;
/*!40000 ALTER TABLE `user_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('admin','accountant','manager','user') DEFAULT 'user',
  `status` enum('active','inactive','deleted') DEFAULT 'active',
  `language` varchar(5) DEFAULT 'ar',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','$2y$10$crLrK32LCHVboWqNS5lEmubXH.YHsyOQoiuFJB1QtXY/qhmJeLNSa','Updated Admin','Updated Admin','admin@test-update.com','admin','active','ar',1,'2025-08-10 16:59:47',NULL,'2025-07-16 12:04:08','2025-08-10 18:15:31',NULL),
(3,'testuser','y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Test User','Test User','test@example.com','user','deleted','ar',1,NULL,NULL,'2025-08-10 18:08:48','2025-08-10 18:14:02',NULL),
(4,'Khan','$2y$10$Z3c49dJ0.8bIANGm99qERet72H9fxsvWhXFID9NvIIoJp8ZJi.7aC','Mohamed Abdulla Ali Farh','Mohamed Abdulla Ali Farh','hmadakhan686@gmail.com','accountant','active','ar',1,'2025-08-10 18:17:55',1,'2025-08-10 18:10:43','2025-08-10 18:17:55',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `cashbox_summary`
--

/*!50001 DROP VIEW IF EXISTS `cashbox_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`khan`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `cashbox_summary` AS select sum(case when `cashbox_movements`.`movement_type` = 'in' then `cashbox_movements`.`amount_rmb` else -`cashbox_movements`.`amount_rmb` end) AS `balance_rmb`,sum(case when `cashbox_movements`.`movement_type` = 'in' then `cashbox_movements`.`amount_usd` else -`cashbox_movements`.`amount_usd` end) AS `balance_usd`,sum(case when `cashbox_movements`.`movement_type` = 'in' then `cashbox_movements`.`amount_sdg` else -`cashbox_movements`.`amount_sdg` end) AS `balance_sdg`,sum(case when `cashbox_movements`.`movement_type` = 'in' then `cashbox_movements`.`amount_aed` else -`cashbox_movements`.`amount_aed` end) AS `balance_aed` from `cashbox_movements` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `client_balances`
--

/*!50001 DROP VIEW IF EXISTS `client_balances`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`khan`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `client_balances` AS select `c`.`id` AS `id`,`c`.`name` AS `name`,`c`.`client_code` AS `client_code`,coalesce(sum(`t`.`balance_rmb`),0) AS `total_balance_rmb`,coalesce(sum(`t`.`balance_usd`),0) AS `total_balance_usd`,count(`t`.`id`) AS `transaction_count` from (`clients` `c` left join `transactions` `t` on(`c`.`id` = `t`.`client_id` and `t`.`status` = 'approved')) group by `c`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-11  2:00:01
